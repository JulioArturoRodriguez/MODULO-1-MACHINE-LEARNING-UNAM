tuple1 = ("manzana", False, 0.5)
print(type(tuple1[1]))
